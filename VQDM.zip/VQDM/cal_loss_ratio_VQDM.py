import os
import re
import torch
import torch.nn as nn
import argparse
from PIL import Image
import torchvision.transforms as T
from diffusers import VQDiffusionPipeline


def extract_numbers(filename):
    return tuple(map(int, re.findall(r'\d+', filename)))

def retrieve_latents(encoder_output, generator=None, sample_mode="sample"):
    if hasattr(encoder_output, "latent_dist") and sample_mode == "sample":
        return encoder_output.latent_dist.sample(generator)
    elif hasattr(encoder_output, "latent_dist") and sample_mode == "argmax":
        return encoder_output.latent_dist.mode()
    elif hasattr(encoder_output, "latents"):
        return encoder_output.latents
    else:
        return encoder_output

# 设置命令行参数
# Set up command line arguments
parser = argparse.ArgumentParser(description='calculate attribution signal')
parser.add_argument('--model_name', type=str, required=True)
parser.add_argument('--filePath', type=str, required=True)
parser.add_argument('--distance_metric', type=str, required=True, choices=['l1', 'l2', 'ssim', 'psnr', 'lpips'])
args = parser.parse_args()


# 模型配置
# Model configuration
model_config = {
    "VQDM": {
        "class": VQDiffusionPipeline,
        "params": {
            "pretrained_model_name_or_path": "microsoft/vq-diffusion-ithq",
            "torch_dtype": torch.float16
        }
    }
}


# 加载模型
# Load the model
generator = torch.Generator().manual_seed(1)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
config = model_config.get(args.model_name)
pipe = config["class"].from_pretrained(**config["params"])
pipe = pipe.to(device)


# 获取模型自编码器
# Get the model's autoencoder
if hasattr(pipe, "vae"):
    ae = pipe.vae
    if hasattr(pipe, "upcast_vae"):
        pipe.upcast_vae()
elif hasattr(pipe, "movq"):
    ae = pipe.movq
elif hasattr(pipe, "vqvae"):
    ae = pipe.vqvae
ae.to(device)
ae = torch.compile(ae)
decode_dtype = ae.dtype


# 选择损失计算函数
# Select the loss calculation function
if args.distance_metric == 'l1':
    criterion = nn.L1Loss()
elif args.distance_metric == 'l2':
    criterion = nn.MSELoss()
elif args.distance_metric == 'ssim':
    from torchmetrics.image import StructuralSimilarityIndexMeasure
    ssim = StructuralSimilarityIndexMeasure(data_range=2.0).to(device)
    criterion = lambda x, y: 1 - ssim((x + 1)/2, (y + 1)/2)
elif args.distance_metric == 'psnr':
    from torchmetrics.image import PeakSignalNoiseRatio
    psnr = PeakSignalNoiseRatio(data_range=2.0).to(device)
    criterion = lambda x, y: -psnr((x + 1)/2, (y + 1)/2)
elif args.distance_metric == 'lpips':
    import lpips
    lpips_model = lpips.LPIPS(net='alex').to(device)
    criterion = lambda x, y: lpips_model(x, y).mean()
else:
    raise ValueError(f"Unsupported metric: {args.distance_metric}")

# 定义输出文件
# Define the output file
image_files = sorted(
    [f for f in os.listdir(args.filePath) if f.lower().endswith(('.png', '.jpg', '.jpeg'))],
    key=extract_numbers)
base_name = f"{args.model_name}_{os.path.basename(args.filePath)}_{args.distance_metric}"


metrics_file = open(f"Result/{base_name}.txt", 'a')
for filename in image_files:
    
    # 图像预处理
    # Image preprocessing
    img_path = os.path.join(args.filePath, filename)
    image = Image.open(img_path).convert('RGB')
    image = image.resize((256, 256))
    transform = T.Compose([T.ToTensor(),])
    orig_image_tensor = transform(image).unsqueeze(0)
    current_input = (orig_image_tensor.to(device) * 2.0 - 1.0).to(ae.dtype)
    orig_image_tensor = current_input
    
    # 双重编解码
    # Double reconstruction
    metric_values, total_values = [], []
    for i in range(2):
        with torch.no_grad():
            latents = retrieve_latents(ae.encode(current_input), generator=generator)
            reconstruction = ae.decode(latents.to(decode_dtype), return_dict=False)[0]
            mse_loss = criterion(reconstruction, current_input)
        
        metric_val = mse_loss.item()
        total_val = criterion(reconstruction, orig_image_tensor).item()
        metric_values.append(f"{metric_val:.8f}")
        total_values.append(f"{total_val:.8f}")
        current_input = reconstruction.detach()

    metrics_file.write(f"{' '.join(metric_values)}\n")
    metrics_file.flush()

metrics_file.close()

# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/FLUX --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/KD2.1 --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/Real --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/SD1.5 --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/SD2.1 --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/SD2base --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/SD3.5 --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/SDXL --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/VQDM --distance_metric l2


# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/VQDM --distance_metric l1
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/VQDM --distance_metric l2
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/VQDM --distance_metric ssim
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/VQDM --distance_metric psnr
# python VQDM/cal_loss_ratio_VQDM.py --model_name VQDM --filePath Imgs/VQDM --distance_metric lpips